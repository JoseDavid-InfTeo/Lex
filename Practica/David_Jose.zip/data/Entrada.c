main()
{ @
//declaraciones
	int a;
	int b,casa23; 
	float f;
//codigo
	printf("Introduce un entero\n"); scanf("%d",&a); 
	if(a) {	
		b=a+1000; 
	}
	else
		f=a+23.5;#
	printf("Adiooooooooos"); 
}
//fin